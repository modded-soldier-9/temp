import { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";
import { User, IUser } from "../models/user.model";

interface TokenPayload {
  id: string;
  type: "access" | "refresh";
}

interface AuthRequest extends Request {
  user?: IUser;
}

// Validate JWT Token
const validateToken = (
  token: string,
  type: "access" | "refresh"
): TokenPayload => {
  try {
    const secret =
      type === "access"
        ? process.env.JWT_ACCESS_SECRET || "your-access-secret-key"
        : process.env.JWT_REFRESH_SECRET || "your-refresh-secret-key";

    const decoded = jwt.verify(token, secret) as TokenPayload;

    if (decoded.type !== type) {
      throw new Error("Invalid token type");
    }

    return decoded;
  } catch (error) {
    throw error;
  }
};

export const protect = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith("Bearer")) {
      res.status(401).json({
        success: false,
        message: "Not authorized, no token",
      });
      return;
    }

    // Get token from header
    const token = authHeader.split(" ")[1];

    // Verify access token
    const decoded = validateToken(token, "access");

    // Get user from token
    const user = await User.findById(decoded.id).select(
      "-password -refreshToken"
    );

    if (!user) {
      res.status(401).json({
        success: false,
        message: "User not found",
      });
      return;
    }

    req.user = user;
    next();
  } catch (error: any) {
    res.status(401).json({
      success: false,
      message: error.message || "Not authorized, token failed",
    });
  }
};

// Generate Access Token (short-lived)
export const generateAccessToken = (id: string): string => {
  return jwt.sign(
    { id, type: "access" } as TokenPayload,
    process.env.JWT_ACCESS_SECRET || "your-access-secret-key",
    {
      expiresIn: "15m", // Short lived token
    }
  );
};

// Generate Refresh Token (long-lived)
export const generateRefreshToken = (id: string): string => {
  return jwt.sign(
    { id, type: "refresh" } as TokenPayload,
    process.env.JWT_REFRESH_SECRET || "your-refresh-secret-key",
    {
      expiresIn: "7d", // Longer lived token
    }
  );
};

// Refresh Access Token
export const refreshAccessToken = async (
  req: Request,
  res: Response
): Promise<void> => {
  const refreshToken = req.body.refreshToken;

  if (!refreshToken) {
    res.status(401).json({
      success: false,
      message: "Refresh token is required",
    });
    return;
  }

  try {
    // Verify refresh token
    const decoded = validateToken(refreshToken, "refresh");

    // Get user
    const user = await User.findById(decoded.id);

    if (!user || user.refreshToken !== refreshToken) {
      throw new Error("Invalid refresh token");
    }

    // Generate new access token
    const accessToken = generateAccessToken(user._id.toString());

    res.json({
      success: true,
      data: {
        accessToken,
      },
    });
  } catch (error: any) {
    res.status(401).json({
      success: false,
      message: error.message || "Invalid refresh token",
    });
  }
};

// Logout user by invalidating refresh token
export const logout = async (
  req: AuthRequest,
  res: Response
): Promise<void> => {
  try {
    if (!req.user) {
      throw new Error("User not found");
    }

    // Clear refresh token in database
    await User.findByIdAndUpdate(req.user._id, { refreshToken: null });

    res.json({
      success: true,
      message: "Logged out successfully",
    });
  } catch (error: any) {
    res.status(400).json({
      success: false,
      message: error.message || "Something went wrong",
    });
  }
};
