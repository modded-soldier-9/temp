import { Request, Response } from "express";
import { User, IUser } from "../models/user.model";
import {
  generateAccessToken,
  generateRefreshToken,
  refreshAccessToken,
  logout,
} from "../middleware/auth.middleware";
import { HydratedDocument } from "mongoose";

export interface AuthenticatedRequest extends Request {
  user?: IUser;
}

export const register = async (req: Request, res: Response): Promise<void> => {
  try {
    const {
      username,
      password,
      age,
      weightGoal,
      currentWeight,
      height,
      activityLevel,
      dietaryPreferences,
      targetWeight,
    } = req.body;

    // Check if user exists
    const userExists = await User.findOne({ username });

    if (userExists) {
      res.status(400).json({
        success: false,
        message: "User already exists",
      });
      return;
    }

    // Create user
    const user: HydratedDocument<IUser> = await User.create({
      username,
      password,
      age,
      weightGoal,
      currentWeight,
      height,
      activityLevel,
      dietaryPreferences,
      targetWeight,
      savedRecipes: [],
    });

    if (user) {
      // Generate tokens
      const accessToken = generateAccessToken(user._id.toString());
      const refreshToken = generateRefreshToken(user._id.toString());

      // Save refresh token to user
      user.refreshToken = refreshToken;
      await user.save();

      res.status(201).json({
        success: true,
        data: {
          _id: user._id,
          username: user.username,
          weightGoal: user.weightGoal,
          activityLevel: user.activityLevel,
          accessToken,
          refreshToken,
        },
      });
    } else {
      res.status(400).json({
        success: false,
        message: "Invalid user data",
      });
    }
  } catch (error: any) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export const login = async (req: Request, res: Response): Promise<void> => {
  try {
    const { username, password } = req.body;

    // Check for user
    const user: HydratedDocument<IUser> | null = await User.findOne({
      username,
    });

    if (!user) {
      res.status(401).json({
        success: false,
        message: "Invalid credentials",
      });
      return;
    }

    // Check password
    const isMatch = await user.comparePassword(password);

    if (!isMatch) {
      res.status(401).json({
        success: false,
        message: "Invalid credentials",
      });
      return;
    }

    // Generate tokens
    const accessToken = generateAccessToken(user._id.toString());
    const refreshToken = generateRefreshToken(user._id.toString());

    // Save refresh token to user
    user.refreshToken = refreshToken;
    await user.save();

    res.json({
      success: true,
      data: {
        _id: user._id,
        username: user.username,
        weightGoal: user.weightGoal,
        activityLevel: user.activityLevel,
        accessToken,
        refreshToken,
      },
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export const getProfile = async (
  req: AuthenticatedRequest,
  res: Response
): Promise<void> => {
  try {
    if (!req.user) {
      res.status(401).json({
        success: false,
        message: "Not authorized",
      });
      return;
    }

    const user = await User.findById(req.user._id).select(
      "-password -refreshToken"
    );

    if (!user) {
      res.status(404).json({
        success: false,
        message: "User not found",
      });
      return;
    }

    res.json({
      success: true,
      data: user,
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export const refreshToken = async (
  req: Request,
  res: Response
): Promise<void> => {
  await refreshAccessToken(req, res);
};

export const logoutUser = async (
  req: AuthenticatedRequest,
  res: Response
): Promise<void> => {
  await logout(req, res);
};
