import { Request, Response } from "express";
import { Types } from "mongoose";
import { Recipe, IRecipe } from "../models/recipe.model";
import { User } from "../models/user.model";
import SpoonacularService from "../services/spoonacular.service";

// Get all recipes with pagination and filters
export const getAllRecipes = async (
  req: Request,
  res: Response
): Promise<void> => {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 10;
    const search = req.query.search as string;
    const dietaryTags = req.query.dietaryTags as string[];

    let query: any = {};

    // Add search functionality
    if (search) {
      query.$text = { $search: search };
    }

    // Add dietary tags filter
    if (dietaryTags && dietaryTags.length > 0) {
      query.dietaryTags = { $in: dietaryTags };
    }

    const recipes = await Recipe.find(query)
      .skip((page - 1) * limit)
      .limit(limit)
      .populate("createdBy", "username")
      .sort({ createdAt: -1 });

    const total = await Recipe.countDocuments(query);

    res.status(200).json({
      success: true,
      data: recipes,
      total,
      pages: Math.ceil(total / limit),
      currentPage: page,
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// Get recipe by ID
export const getRecipeById = async (
  req: Request,
  res: Response
): Promise<void> => {
  try {
    const recipe = await Recipe.findById(req.params.id).populate(
      "createdBy",
      "username"
    );

    if (!recipe) {
      res.status(404).json({
        success: false,
        message: "Recipe not found",
      });
      return;
    }

    res.status(200).json({
      success: true,
      data: recipe,
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// Create new recipe
export const createRecipe = async (
  req: Request,
  res: Response
): Promise<void> => {
  try {
    const userId = (req as any).user._id;
    const recipeData = { ...req.body, createdBy: userId };

    const recipe = await Recipe.create(recipeData);
    await recipe.populate("createdBy", "username");

    res.status(201).json({
      success: true,
      data: recipe,
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// Update recipe
export const updateRecipe = async (
  req: Request,
  res: Response
): Promise<void> => {
  try {
    const userId = (req as any).user._id;
    const recipe = await Recipe.findById(req.params.id);

    if (!recipe) {
      res.status(404).json({
        success: false,
        message: "Recipe not found",
      });
      return;
    }

    if (recipe.createdBy.toString() !== userId) {
      res.status(403).json({
        success: false,
        message: "Not authorized to update this recipe",
      });
      return;
    }

    const updatedRecipe = await Recipe.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    ).populate("createdBy", "username");

    res.status(200).json({
      success: true,
      data: updatedRecipe,
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// Delete recipe
export const deleteRecipe = async (
  req: Request,
  res: Response
): Promise<void> => {
  try {
    const userId = (req as any).user._id;
    const recipe = await Recipe.findById(req.params.id);

    if (!recipe) {
      res.status(404).json({
        success: false,
        message: "Recipe not found",
      });
      return;
    }

    if (recipe.createdBy.toString() !== userId) {
      res.status(403).json({
        success: false,
        message: "Not authorized to delete this recipe",
      });
      return;
    }

    await recipe.deleteOne();

    res.status(200).json({
      success: true,
      data: {},
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// Save recipe to user's saved recipes
export const saveRecipe = async (
  req: Request,
  res: Response
): Promise<void> => {
  try {
    const userId = (req as any).user._id;
    const recipeId = req.params.id;

    const user = await User.findById(userId);
    const recipe = await Recipe.findById(recipeId);

    if (!user || !recipe) {
      res.status(404).json({
        success: false,
        message: "User or Recipe not found",
      });
      return;
    }

    if (user.savedRecipes.includes(new Types.ObjectId(recipeId))) {
      res.status(400).json({
        success: false,
        message: "Recipe already saved",
      });
      return;
    }

    user.savedRecipes.push(new Types.ObjectId(recipeId));
    await user.save();

    res.status(200).json({
      success: true,
      data: recipe,
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// Remove recipe from user's saved recipes
export const unsaveRecipe = async (
  req: Request,
  res: Response
): Promise<void> => {
  try {
    const userId = (req as any).user._id;
    const recipeId = req.params.id;

    const user = await User.findById(userId);

    if (!user) {
      res.status(404).json({
        success: false,
        message: "User not found",
      });
      return;
    }

    user.savedRecipes = user.savedRecipes.filter(
      (id) => id.toString() !== recipeId
    );
    await user.save();

    res.status(200).json({
      success: true,
      data: {},
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// Rate recipe
export const rateRecipe = async (
  req: Request,
  res: Response
): Promise<void> => {
  try {
    const userId = (req as any).user._id;
    const { score, comment } = req.body;

    if (!score || score < 1 || score > 5) {
      res.status(400).json({
        success: false,
        message: "Invalid rating score",
      });
      return;
    }

    const recipe = await Recipe.findById(req.params.id);

    if (!recipe) {
      res.status(404).json({
        success: false,
        message: "Recipe not found",
      });
      return;
    }

    // Check if user has already rated
    const existingRating = recipe.ratings.find(
      (rating) => rating.user.toString() === userId
    );

    if (existingRating) {
      existingRating.score = score;
      if (comment) existingRating.comment = comment;
    } else {
      recipe.ratings.push({ user: userId, score, comment });
    }

    await recipe.save();
    await recipe.populate("createdBy", "username");

    res.status(200).json({
      success: true,
      data: recipe,
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// Get user's saved recipes
export const getSavedRecipes = async (
  req: Request,
  res: Response
): Promise<void> => {
  try {
    const userId = (req as any).user._id;
    const user = await User.findById(userId).populate("savedRecipes");

    if (!user) {
      res.status(404).json({
        success: false,
        message: "User not found",
      });
      return;
    }

    res.status(200).json({
      success: true,
      data: user.savedRecipes,
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// Search recipes using Spoonacular API
export const searchSpoonacularRecipes = async (
  req: Request,
  res: Response
): Promise<void> => {
  try {
    const { query, diet, intolerances } = req.query as {
      query?: string;
      diet?: string;
      intolerances?: string;
    };

    if (!query) {
      res.status(400).json({
        success: false,
        message: "Search query is required",
      });
      return;
    }

    const recipes = await SpoonacularService.searchRecipes(
      query,
      diet,
      intolerances
    );

    res.status(200).json({
      success: true,
      data: recipes,
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// Get recipe recommendations based on user preferences
export const getRecipeRecommendations = async (
  req: Request,
  res: Response
): Promise<void> => {
  try {
    const userId = (req as any).user._id;
    const user = await User.findById(userId);

    if (!user) {
      res.status(404).json({
        success: false,
        message: "User not found",
      });
      return;
    }

    const recipes = await SpoonacularService.getRecipeRecommendations(
      user.dietaryPreferences,
      req.query.targetCalories ? Number(req.query.targetCalories) : undefined,
      req.query.excludeIngredients as string[]
    );

    res.status(200).json({
      success: true,
      data: recipes,
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// Get recipes by ingredients
export const getRecipesByIngredients = async (
  req: Request,
  res: Response
): Promise<void> => {
  try {
    const ingredients = req.query.ingredients as string[];

    if (
      !ingredients ||
      !Array.isArray(ingredients) ||
      ingredients.length === 0
    ) {
      res.status(400).json({
        success: false,
        message: "Ingredients array is required",
      });
      return;
    }

    const recipes = await SpoonacularService.getRecipesByIngredients(
      ingredients
    );

    res.status(200).json({
      success: true,
      data: recipes,
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};
