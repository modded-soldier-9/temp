import mongoose, { Document, Model, Types } from "mongoose";
import bcrypt from "bcryptjs";

interface WeightEntry {
  weight: number;
  date: Date;
}

export interface IUserBase {
  username: string;
  password: string;
  age?: number;
  weightGoal: "lose" | "maintain" | "gain";
  currentWeight?: number;
  height?: number;
  activityLevel: "sedentary" | "light" | "moderate" | "very" | "extremely";
  dietaryPreferences: string[];
  targetWeight?: number;
  savedRecipes: Types.ObjectId[];
  weightHistory: WeightEntry[];
  refreshToken?: string;
  calorieGoal?: number;
  macroGoals?: {
    protein: number;
    carbs: number;
    fat: number;
  };
  lastWeightUpdate?: Date;
}

export interface IUserDocument extends IUserBase, Document {
  _id: Types.ObjectId;
  comparePassword(candidatePassword: string): Promise<boolean>;
}

export interface IUser extends IUserDocument {}

export interface IUserModel extends Model<IUserDocument> {
  comparePassword?(candidatePassword: string): Promise<boolean>;
}

const weightEntrySchema = new mongoose.Schema({
  weight: {
    type: Number,
    required: true,
  },
  date: {
    type: Date,
    default: Date.now,
  },
});

const userSchema = new mongoose.Schema<IUserDocument>(
  {
    username: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },
    password: {
      type: String,
      required: true,
    },
    age: {
      type: Number,
    },
    weightGoal: {
      type: String,
      enum: ["lose", "maintain", "gain"],
      required: true,
    },
    currentWeight: {
      type: Number,
    },
    height: {
      type: Number,
    },
    activityLevel: {
      type: String,
      enum: ["sedentary", "light", "moderate", "very", "extremely"],
      required: true,
    },
    dietaryPreferences: [
      {
        type: String,
      },
    ],
    targetWeight: {
      type: Number,
    },
    savedRecipes: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Recipe",
      },
    ],
    weightHistory: [weightEntrySchema],
    refreshToken: {
      type: String,
    },
    calorieGoal: {
      type: Number,
    },
    macroGoals: {
      protein: { type: Number },
      carbs: { type: Number },
      fat: { type: Number },
    },
    lastWeightUpdate: {
      type: Date,
    },
  },
  {
    timestamps: true,
  }
);

// Hash password before saving
userSchema.pre("save", async function (next) {
  if (!this.isModified("password")) {
    return next();
  }

  try {
    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.password, salt);
    next();
  } catch (error: any) {
    next(error);
  }
});

// Method to compare password for login
userSchema.methods.comparePassword = async function (
  candidatePassword: string
): Promise<boolean> {
  try {
    return await bcrypt.compare(candidatePassword, this.password);
  } catch (error) {
    throw error;
  }
};

// Method to update weight
userSchema.methods.updateWeight = async function (
  weight: number
): Promise<void> {
  this.currentWeight = weight;
  this.lastWeightUpdate = new Date();
  this.weightHistory.push({ weight, date: new Date() });
  await this.save();
};

// Method to calculate BMR (Basal Metabolic Rate) using Harris-Benedict equation
userSchema.methods.calculateBMR = function (): number {
  if (!this.currentWeight || !this.height || !this.age) {
    throw new Error("Missing required fields for BMR calculation");
  }

  // Weight in kg, height in cm
  if (this.height > 3) {
    // Assuming height was provided in cm
    this.height = this.height / 100; // Convert to meters
  }

  const bmr =
    10 * this.currentWeight + 6.25 * (this.height * 100) - 5 * this.age;
  return bmr;
};

// Method to calculate daily calorie needs
userSchema.methods.calculateCalorieNeeds = function (): number {
  const bmr = this.calculateBMR();
  let activityMultiplier = 1.2; // sedentary

  switch (this.activityLevel) {
    case "light":
      activityMultiplier = 1.375;
      break;
    case "moderate":
      activityMultiplier = 1.55;
      break;
    case "very":
      activityMultiplier = 1.725;
      break;
    case "extremely":
      activityMultiplier = 1.9;
      break;
  }

  let tdee = bmr * activityMultiplier;

  // Adjust based on weight goal
  switch (this.weightGoal) {
    case "lose":
      tdee -= 500; // Create a 500 calorie deficit
      break;
    case "gain":
      tdee += 500; // Create a 500 calorie surplus
      break;
  }

  return Math.round(tdee);
};

// Method to update calorie and macro goals
userSchema.methods.updateNutritionGoals = async function (): Promise<void> {
  const calorieNeeds = this.calculateCalorieNeeds();
  this.calorieGoal = calorieNeeds;

  // Calculate macro splits (40% protein, 30% carbs, 30% fat for weight loss)
  // Adjust these percentages based on the weight goal
  let proteinPct = 0.4;
  let carbsPct = 0.3;
  let fatPct = 0.3;

  if (this.weightGoal === "maintain") {
    proteinPct = 0.3;
    carbsPct = 0.4;
    fatPct = 0.3;
  } else if (this.weightGoal === "gain") {
    proteinPct = 0.25;
    carbsPct = 0.45;
    fatPct = 0.3;
  }

  this.macroGoals = {
    protein: Math.round((calorieNeeds * proteinPct) / 4), // 4 calories per gram of protein
    carbs: Math.round((calorieNeeds * carbsPct) / 4), // 4 calories per gram of carbs
    fat: Math.round((calorieNeeds * fatPct) / 9), // 9 calories per gram of fat
  };

  await this.save();
};

export const User = mongoose.model<IUserDocument, IUserModel>(
  "User",
  userSchema
);
