import mongoose, { Document, Model, Types } from "mongoose";

export interface IRecipeBase {
  name: string;
  ingredients: string[];
  instructions: string[];
  nutritionalInfo: {
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
  };
  preparationTime: number;
  difficulty: "easy" | "medium" | "hard";
  dietaryTags: string[];
  createdBy: Types.ObjectId;
  ratings: {
    user: Types.ObjectId;
    score: number;
    comment?: string;
  }[];
}

export interface IRecipeDocument extends IRecipeBase, Document {
  _id: Types.ObjectId;
  averageRating: number;
}

export interface IRecipe extends IRecipeDocument {}

export interface IRecipeModel extends Model<IRecipeDocument> {}

const recipeSchema = new mongoose.Schema<IRecipeDocument>(
  {
    name: {
      type: String,
      required: true,
      trim: true,
    },
    ingredients: [
      {
        type: String,
        required: true,
      },
    ],
    instructions: [
      {
        type: String,
        required: true,
      },
    ],
    nutritionalInfo: {
      calories: {
        type: Number,
        required: true,
      },
      protein: {
        type: Number,
        required: true,
      },
      carbs: {
        type: Number,
        required: true,
      },
      fat: {
        type: Number,
        required: true,
      },
    },
    preparationTime: {
      type: Number,
      required: true,
    },
    difficulty: {
      type: String,
      enum: ["easy", "medium", "hard"],
      required: true,
    },
    dietaryTags: [
      {
        type: String,
      },
    ],
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    ratings: [
      {
        user: {
          type: mongoose.Schema.Types.ObjectId,
          ref: "User",
          required: true,
        },
        score: {
          type: Number,
          required: true,
          min: 1,
          max: 5,
        },
        comment: {
          type: String,
        },
      },
    ],
  },
  {
    timestamps: true,
  }
);

// Add index for searching recipes by name
recipeSchema.index({ name: "text", dietaryTags: "text" });

// Virtual for average rating
recipeSchema.virtual("averageRating").get(function (this: IRecipeDocument) {
  if (this.ratings.length === 0) {
    return 0;
  }
  const sum = this.ratings.reduce((total, rating) => total + rating.score, 0);
  return sum / this.ratings.length;
});

export const Recipe = mongoose.model<IRecipeDocument, IRecipeModel>(
  "Recipe",
  recipeSchema
);
