import express, { Router } from "express";
import {
  getAllRecipes,
  getRecipeById,
  createRecipe,
  updateRecipe,
  deleteRecipe,
  saveRecipe,
  unsaveRecipe,
  rateRecipe,
  getSavedRecipes,
  searchSpoonacularRecipes,
  getRecipeRecommendations,
  getRecipesByIngredients,
} from "../controllers/recipe.controller";
import { protect } from "../middleware/auth.middleware";

const router: Router = express.Router();

// Public routes
router.get("/", getAllRecipes);
router.get("/:id", getRecipeById);

// Protected routes
router.post("/", protect, createRecipe);
router.put("/:id", protect, updateRecipe);
router.delete("/:id", protect, deleteRecipe);
router.post("/:id/save", protect, saveRecipe);
router.delete("/:id/save", protect, unsaveRecipe);
router.post("/:id/rate", protect, rateRecipe);
router.get("/user/saved", protect, getSavedRecipes);

// Spoonacular API routes
router.get("/search/spoonacular", protect, searchSpoonacularRecipes);
router.get("/recommendations", protect, getRecipeRecommendations);
router.get("/by-ingredients", protect, getRecipesByIngredients);

export default router;
