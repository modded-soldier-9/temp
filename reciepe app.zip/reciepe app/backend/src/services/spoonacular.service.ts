import axios from "axios";
import { IRecipeBase } from "../models/recipe.model";

const API_KEY = process.env.SPOONACULAR_API_KEY;
const BASE_URL = "https://api.spoonacular.com";

interface SpoonacularRecipe {
  id: number;
  title: string;
  readyInMinutes: number;
  servings: number;
  sourceUrl: string;
  image: string;
  nutrition: {
    nutrients: {
      name: string;
      amount: number;
      unit: string;
    }[];
  };
  analyzedInstructions: {
    steps: {
      number: number;
      step: string;
      ingredients: { name: string }[];
    }[];
  }[];
  diets: string[];
  extendedIngredients: {
    original: string;
  }[];
}

class SpoonacularService {
  private api;

  constructor() {
    this.api = axios.create({
      baseURL: BASE_URL,
      params: {
        apiKey: API_KEY,
      },
    });
  }

  private mapToRecipeModel(
    spoonRecipe: SpoonacularRecipe
  ): Partial<IRecipeBase> {
    const nutrients = spoonRecipe.nutrition.nutrients;
    return {
      name: spoonRecipe.title,
      ingredients: spoonRecipe.extendedIngredients.map((ing) => ing.original),
      instructions:
        spoonRecipe.analyzedInstructions[0]?.steps.map((step) => step.step) ||
        [],
      nutritionalInfo: {
        calories: this.getNutrientAmount(nutrients, "Calories"),
        protein: this.getNutrientAmount(nutrients, "Protein"),
        carbs: this.getNutrientAmount(nutrients, "Carbohydrates"),
        fat: this.getNutrientAmount(nutrients, "Fat"),
      },
      preparationTime: spoonRecipe.readyInMinutes,
      difficulty: this.calculateDifficulty(
        spoonRecipe.readyInMinutes,
        spoonRecipe.extendedIngredients.length
      ),
      dietaryTags: spoonRecipe.diets,
    };
  }

  private getNutrientAmount(
    nutrients: { name: string; amount: number }[],
    name: string
  ): number {
    return nutrients.find((n) => n.name === name)?.amount || 0;
  }

  private calculateDifficulty(
    prepTime: number,
    ingredientCount: number
  ): "easy" | "medium" | "hard" {
    const score = prepTime / 30 + ingredientCount / 8;
    if (score <= 1.5) return "easy";
    if (score <= 3) return "medium";
    return "hard";
  }

  async searchRecipes(
    query: string,
    diet?: string,
    intolerances?: string
  ): Promise<Partial<IRecipeBase>[]> {
    try {
      const { data } = await this.api.get("/recipes/complexSearch", {
        params: {
          query,
          diet,
          intolerances,
          addRecipeNutrition: true,
          addRecipeInformation: true,
          number: 10,
        },
      });

      return data.results.map((recipe: SpoonacularRecipe) =>
        this.mapToRecipeModel(recipe)
      );
    } catch (error) {
      console.error("Error searching recipes:", error);
      throw error;
    }
  }

  async getRecipesByIngredients(
    ingredients: string[]
  ): Promise<Partial<IRecipeBase>[]> {
    try {
      const { data } = await this.api.get("/recipes/findByIngredients", {
        params: {
          ingredients: ingredients.join(","),
          number: 10,
          ranking: 2, // Maximize used ingredients
          ignorePantry: true,
        },
      });

      // Get full recipe information for each found recipe
      const recipePromises = data.map(async (recipe: { id: number }) => {
        const { data: fullRecipe } = await this.api.get(
          `/recipes/${recipe.id}/information`,
          {
            params: {
              includeNutrition: true,
            },
          }
        );
        return this.mapToRecipeModel(fullRecipe);
      });

      return Promise.all(recipePromises);
    } catch (error) {
      console.error("Error getting recipes by ingredients:", error);
      throw error;
    }
  }

  async getRecipeRecommendations(
    diet: string[],
    targetCalories?: number,
    excludeIngredients?: string[]
  ): Promise<Partial<IRecipeBase>[]> {
    try {
      const { data } = await this.api.get("/recipes/complexSearch", {
        params: {
          diet: diet.join(","),
          maxCalories: targetCalories,
          excludeIngredients: excludeIngredients?.join(","),
          addRecipeNutrition: true,
          addRecipeInformation: true,
          number: 10,
          sort: "random",
        },
      });

      return data.results.map((recipe: SpoonacularRecipe) =>
        this.mapToRecipeModel(recipe)
      );
    } catch (error) {
      console.error("Error getting recipe recommendations:", error);
      throw error;
    }
  }
}

export default new SpoonacularService();
