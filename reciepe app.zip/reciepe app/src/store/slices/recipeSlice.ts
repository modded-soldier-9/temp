import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import axios from "axios";

interface Rating {
  user: string;
  score: number;
  comment?: string;
}

interface Recipe {
  _id: string;
  name: string;
  ingredients: string[];
  instructions: string[];
  nutritionalInfo: {
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
  };
  preparationTime: number;
  difficulty: "easy" | "medium" | "hard";
  dietaryTags: string[];
  createdBy: string;
  ratings: Rating[];
  averageRating: number;
}

interface SpoonacularRecipe {
  name: string;
  ingredients: string[];
  instructions: string[];
  nutritionalInfo: {
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
  };
  preparationTime: number;
  difficulty: "easy" | "medium" | "hard";
  dietaryTags: string[];
}

interface RecipeState {
  recipes: Recipe[];
  userRecipes: Recipe[];
  savedRecipes: Recipe[];
  currentRecipe: Recipe | null;
  searchResults: SpoonacularRecipe[];
  recommendations: SpoonacularRecipe[];
  ingredientBasedRecipes: SpoonacularRecipe[];
  isLoading: boolean;
  error: string | null;
}

const initialState: RecipeState = {
  recipes: [],
  userRecipes: [],
  savedRecipes: [],
  currentRecipe: null,
  searchResults: [],
  recommendations: [],
  ingredientBasedRecipes: [],
  isLoading: false,
  error: null,
};

// Get all recipes
export const getAllRecipes = createAsyncThunk(
  "recipes/getAll",
  async (_, { rejectWithValue }) => {
    try {
      const response = await axios.get("http://localhost:5000/api/recipes");
      return response.data.data;
    } catch (error: any) {
      return rejectWithValue(
        error.response?.data?.message || "Failed to fetch recipes"
      );
    }
  }
);

// Get user's recipes
export const getUserRecipes = createAsyncThunk(
  "recipes/getUserRecipes",
  async (userId: string, { rejectWithValue }) => {
    try {
      const response = await axios.get(
        `http://localhost:5000/api/recipes/user/${userId}`
      );
      return response.data.data;
    } catch (error: any) {
      return rejectWithValue(
        error.response?.data?.message || "Failed to fetch user recipes"
      );
    }
  }
);

// Get saved recipes
export const getSavedRecipes = createAsyncThunk(
  "recipes/getSaved",
  async (_, { rejectWithValue }) => {
    try {
      const response = await axios.get(
        "http://localhost:5000/api/recipes/user/saved"
      );
      return response.data.data;
    } catch (error: any) {
      return rejectWithValue(
        error.response?.data?.message || "Failed to fetch saved recipes"
      );
    }
  }
);

// Create new recipe
export const createRecipe = createAsyncThunk(
  "recipes/create",
  async (recipeData: Partial<Recipe>, { rejectWithValue }) => {
    try {
      const response = await axios.post(
        "http://localhost:5000/api/recipes",
        recipeData
      );
      return response.data.data;
    } catch (error: any) {
      return rejectWithValue(
        error.response?.data?.message || "Failed to create recipe"
      );
    }
  }
);

// Save recipe
export const saveRecipe = createAsyncThunk(
  "recipes/save",
  async (recipeId: string, { rejectWithValue }) => {
    try {
      const response = await axios.post(
        `http://localhost:5000/api/recipes/${recipeId}/save`
      );
      return response.data.data;
    } catch (error: any) {
      return rejectWithValue(
        error.response?.data?.message || "Failed to save recipe"
      );
    }
  }
);

// Unsave recipe
export const unsaveRecipe = createAsyncThunk(
  "recipes/unsave",
  async (recipeId: string, { rejectWithValue }) => {
    try {
      await axios.delete(`http://localhost:5000/api/recipes/${recipeId}/save`);
      return recipeId;
    } catch (error: any) {
      return rejectWithValue(
        error.response?.data?.message || "Failed to unsave recipe"
      );
    }
  }
);

// Search recipes using Spoonacular
export const searchSpoonacularRecipes = createAsyncThunk(
  "recipes/searchSpoonacular",
  async (
    params: { query: string; diet?: string; intolerances?: string },
    { rejectWithValue }
  ) => {
    try {
      const response = await axios.get(
        `http://localhost:5000/api/recipes/search/spoonacular`,
        { params }
      );
      return response.data.data;
    } catch (error: any) {
      return rejectWithValue(
        error.response?.data?.message || "Failed to search recipes"
      );
    }
  }
);

// Get recipe recommendations
export const getRecipeRecommendations = createAsyncThunk(
  "recipes/recommendations",
  async (
    params: { targetCalories?: number; excludeIngredients?: string[] },
    { rejectWithValue }
  ) => {
    try {
      const response = await axios.get(
        `http://localhost:5000/api/recipes/recommendations`,
        { params }
      );
      return response.data.data;
    } catch (error: any) {
      return rejectWithValue(
        error.response?.data?.message || "Failed to get recipe recommendations"
      );
    }
  }
);

// Get recipes by ingredients
export const getRecipesByIngredients = createAsyncThunk(
  "recipes/byIngredients",
  async (ingredients: string[], { rejectWithValue }) => {
    try {
      const response = await axios.get(
        `http://localhost:5000/api/recipes/by-ingredients`,
        { params: { ingredients } }
      );
      return response.data.data;
    } catch (error: any) {
      return rejectWithValue(
        error.response?.data?.message || "Failed to get recipes by ingredients"
      );
    }
  }
);

const recipeSlice = createSlice({
  name: "recipes",
  initialState,
  reducers: {
    setCurrentRecipe: (state, action: PayloadAction<Recipe>) => {
      state.currentRecipe = action.payload;
    },
    clearCurrentRecipe: (state) => {
      state.currentRecipe = null;
    },
    clearError: (state) => {
      state.error = null;
    },
    clearSearchResults: (state) => {
      state.searchResults = [];
    },
    clearRecommendations: (state) => {
      state.recommendations = [];
    },
    clearIngredientBasedRecipes: (state) => {
      state.ingredientBasedRecipes = [];
    },
  },
  extraReducers: (builder) => {
    builder
      // Get all recipes
      .addCase(getAllRecipes.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(
        getAllRecipes.fulfilled,
        (state, action: PayloadAction<Recipe[]>) => {
          state.isLoading = false;
          state.recipes = action.payload;
        }
      )
      .addCase(getAllRecipes.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      // Get user recipes
      .addCase(getUserRecipes.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(
        getUserRecipes.fulfilled,
        (state, action: PayloadAction<Recipe[]>) => {
          state.isLoading = false;
          state.userRecipes = action.payload;
        }
      )
      .addCase(getUserRecipes.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      // Get saved recipes
      .addCase(getSavedRecipes.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(
        getSavedRecipes.fulfilled,
        (state, action: PayloadAction<Recipe[]>) => {
          state.isLoading = false;
          state.savedRecipes = action.payload;
        }
      )
      .addCase(getSavedRecipes.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      // Create recipe
      .addCase(createRecipe.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(
        createRecipe.fulfilled,
        (state, action: PayloadAction<Recipe>) => {
          state.isLoading = false;
          state.recipes.push(action.payload);
          state.userRecipes.push(action.payload);
        }
      )
      .addCase(createRecipe.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      // Save recipe
      .addCase(saveRecipe.fulfilled, (state, action: PayloadAction<Recipe>) => {
        state.savedRecipes.push(action.payload);
      })
      .addCase(saveRecipe.rejected, (state, action) => {
        state.error = action.payload as string;
      })
      // Unsave recipe
      .addCase(
        unsaveRecipe.fulfilled,
        (state, action: PayloadAction<string>) => {
          state.savedRecipes = state.savedRecipes.filter(
            (recipe) => recipe._id !== action.payload
          );
        }
      )
      .addCase(unsaveRecipe.rejected, (state, action) => {
        state.error = action.payload as string;
      })
      // Search Spoonacular recipes
      .addCase(searchSpoonacularRecipes.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(
        searchSpoonacularRecipes.fulfilled,
        (state, action: PayloadAction<SpoonacularRecipe[]>) => {
          state.isLoading = false;
          state.searchResults = action.payload;
        }
      )
      .addCase(searchSpoonacularRecipes.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      // Get recipe recommendations
      .addCase(getRecipeRecommendations.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(
        getRecipeRecommendations.fulfilled,
        (state, action: PayloadAction<SpoonacularRecipe[]>) => {
          state.isLoading = false;
          state.recommendations = action.payload;
        }
      )
      .addCase(getRecipeRecommendations.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      // Get recipes by ingredients
      .addCase(getRecipesByIngredients.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(
        getRecipesByIngredients.fulfilled,
        (state, action: PayloadAction<SpoonacularRecipe[]>) => {
          state.isLoading = false;
          state.ingredientBasedRecipes = action.payload;
        }
      )
      .addCase(getRecipesByIngredients.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      });
  },
});

export const {
  setCurrentRecipe,
  clearCurrentRecipe,
  clearError,
  clearSearchResults,
  clearRecommendations,
  clearIngredientBasedRecipes,
} = recipeSlice.actions;
export default recipeSlice.reducer;
