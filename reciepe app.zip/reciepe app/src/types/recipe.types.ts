export interface Recipe {
  _id: string;
  name: string;
  ingredients: string[];
  instructions: string[];
  nutritionalInfo: {
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
  };
  preparationTime: number;
  difficulty: "easy" | "medium" | "hard";
  dietaryTags: string[];
  createdBy: string;
  ratings: {
    user: string;
    score: number;
    comment?: string;
  }[];
  averageRating: number;
}

export interface RecipeState {
  recipes: Recipe[];
  savedRecipes: Recipe[];
  currentRecipe: Recipe | null;
  loading: boolean;
  error: string | null;
}

export interface RecipeFilters {
  search?: string;
  dietaryTags?: string[];
  difficulty?: "easy" | "medium" | "hard";
  maxPrepTime?: number;
}

export interface GenerateRecipeParams {
  ingredients?: string[];
  dietaryPreferences?: string[];
  targetCalories?: number;
  excludeIngredients?: string[];
}
