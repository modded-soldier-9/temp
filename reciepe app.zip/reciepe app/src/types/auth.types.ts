export interface User {
  _id: string;
  username: string;
  age?: number;
  weightGoal: "lose" | "maintain" | "gain";
  currentWeight?: number;
  height?: number;
  activityLevel: "sedentary" | "light" | "moderate" | "very" | "extremely";
  dietaryPreferences: string[];
  targetWeight?: number;
  savedRecipes: string[];
  createdAt: string;
  updatedAt: string;
}

export interface AuthState {
  user: User | null;
  token: string | null;
  loading: boolean;
  error: string | null;
}

export interface LoginCredentials {
  username: string;
  password: string;
}

export interface RegisterData extends LoginCredentials {
  weightGoal: "lose" | "maintain" | "gain";
  activityLevel: "sedentary" | "light" | "moderate" | "very" | "extremely";
  dietaryPreferences: string[];
}
