import React from "react";
import RecipeGeneratorComponent from "../components/recipe/RecipeGenerator";

const RecipeGenerator: React.FC = () => {
  return <RecipeGeneratorComponent />;
};

export default RecipeGenerator;
