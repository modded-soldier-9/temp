import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  Container,
  Typography,
  Grid,
  Button,
  Box,
  CircularProgress,
} from "@mui/material";
import { Link as RouterLink } from "react-router-dom";
import { AppDispatch, RootState } from "../store";
import {
  getSavedRecipes,
  getRecipeRecommendations,
} from "../store/slices/recipeSlice";
import RecipeCard from "../components/recipe/RecipeCard";

const Home: React.FC = () => {
  const dispatch = useDispatch<AppDispatch>();
  const { user } = useSelector((state: RootState) => state.auth);
  const { savedRecipes, recommendations, isLoading } = useSelector(
    (state: RootState) => state.recipe
  );

  useEffect(() => {
    if (user) {
      dispatch(getSavedRecipes());
      dispatch(
        getRecipeRecommendations({
          targetCalories: 2000, // Default value
          excludeIngredients: [],
        })
      );
    }
  }, [dispatch, user]);

  const handleViewRecipe = (recipe: any) => {
    // TODO: Navigate to recipe details
    console.log("View recipe:", recipe);
  };

  return (
    <Container maxWidth="lg" sx={{ py: 4 }}>
      <Box
        display="flex"
        justifyContent="space-between"
        alignItems="center"
        mb={4}
      >
        <Typography variant="h4" component="h1" gutterBottom>
          Welcome{user ? `, ${user.username}!` : "!"}
        </Typography>
        <Button
          component={RouterLink}
          to="/recipes/generate"
          variant="contained"
          color="primary"
        >
          Generate New Recipes
        </Button>
      </Box>

      <Typography variant="h5" component="h2" gutterBottom sx={{ mt: 4 }}>
        Your Saved Recipes
      </Typography>
      {isLoading ? (
        <Box display="flex" justifyContent="center" my={4}>
          <CircularProgress />
        </Box>
      ) : savedRecipes.length > 0 ? (
        <Grid container spacing={3}>
          {savedRecipes.map((recipe) => (
            <Grid item xs={12} sm={6} md={4} key={recipe._id}>
              <RecipeCard recipe={recipe} onView={handleViewRecipe} />
            </Grid>
          ))}
        </Grid>
      ) : (
        <Typography color="textSecondary">No saved recipes yet.</Typography>
      )}

      <Typography variant="h5" component="h2" gutterBottom sx={{ mt: 6 }}>
        Recommended for You
      </Typography>
      {isLoading ? (
        <Box display="flex" justifyContent="center" my={4}>
          <CircularProgress />
        </Box>
      ) : recommendations.length > 0 ? (
        <Grid container spacing={3}>
          {recommendations.map((recipe, index) => (
            <Grid item xs={12} sm={6} md={4} key={index}>
              <RecipeCard recipe={recipe as any} onView={handleViewRecipe} />
            </Grid>
          ))}
        </Grid>
      ) : (
        <Typography color="textSecondary">
          No recommendations available.
        </Typography>
      )}
    </Container>
  );
};

export default Home;
