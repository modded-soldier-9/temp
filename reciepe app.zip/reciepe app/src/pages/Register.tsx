import React from "react";
import { Box, Paper, Typography } from "@mui/material";

const Register: React.FC = () => {
  return (
    <Box
      sx={{
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        p: 2,
      }}
    >
      <Paper
        elevation={3}
        sx={{
          p: 4,
          maxWidth: 600,
          width: "100%",
        }}
      >
        <Typography variant="h4" component="h1" gutterBottom align="center">
          Register
        </Typography>
        {/* TODO: Add registration form with all user details */}
      </Paper>
    </Box>
  );
};

export default Register;
