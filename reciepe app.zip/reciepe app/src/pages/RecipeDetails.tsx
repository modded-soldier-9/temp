import React from "react";
import {
  Box,
  Container,
  Typography,
  Paper,
  Grid,
  Chip,
  Divider,
  List,
  ListItem,
  ListItemText,
  Rating,
  Button,
  CircularProgress,
} from "@mui/material";
import { useParams } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { RootState, AppDispatch } from "../store";
import { saveRecipe, unsaveRecipe } from "../store/slices/recipeSlice";

const getDifficultyColor = (difficulty: string) => {
  switch (difficulty) {
    case "easy":
      return "success";
    case "medium":
      return "warning";
    case "hard":
      return "error";
    default:
      return "default";
  }
};

const RecipeDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const dispatch = useDispatch<AppDispatch>();

  const { user } = useSelector((state: RootState) => state.auth);
  const {
    currentRecipe: recipe,
    savedRecipes,
    loading,
  } = useSelector((state: RootState) => state.recipe);

  const isSaved = savedRecipes.some((saved) => saved._id === recipe?._id);

  const handleSaveToggle = () => {
    if (!recipe) return;
    if (isSaved) {
      dispatch(unsaveRecipe(recipe._id));
    } else {
      dispatch(saveRecipe(recipe._id));
    }
  };

  if (loading) {
    return (
      <Box
        display="flex"
        justifyContent="center"
        alignItems="center"
        minHeight="60vh"
      >
        <CircularProgress />
      </Box>
    );
  }

  if (!recipe) {
    return (
      <Box
        display="flex"
        justifyContent="center"
        alignItems="center"
        minHeight="60vh"
      >
        <Typography variant="h5">Recipe not found</Typography>
      </Box>
    );
  }

  return (
    <Container maxWidth="lg">
      <Paper elevation={3} sx={{ p: 4, my: 4 }}>
        <Grid container spacing={4}>
          <Grid item xs={12}>
            <Box
              display="flex"
              justifyContent="space-between"
              alignItems="flex-start"
            >
              <Box>
                <Typography variant="h4" gutterBottom>
                  {recipe.name}
                </Typography>
                <Box display="flex" alignItems="center" gap={1} mb={2}>
                  <Rating
                    value={recipe.averageRating}
                    readOnly
                    precision={0.5}
                  />
                  <Typography variant="body2" color="text.secondary">
                    ({recipe.averageRating.toFixed(1)})
                  </Typography>
                </Box>
              </Box>
              {user && (
                <Button
                  variant={isSaved ? "outlined" : "contained"}
                  onClick={handleSaveToggle}
                >
                  {isSaved ? "Unsave Recipe" : "Save Recipe"}
                </Button>
              )}
            </Box>
            <Box display="flex" flexWrap="wrap" gap={1} mb={3}>
              <Chip
                label={recipe.difficulty}
                color={getDifficultyColor(recipe.difficulty) as any}
              />
              <Chip
                label={`${recipe.preparationTime} minutes`}
                color="primary"
              />
              {recipe.dietaryTags.map((tag) => (
                <Chip key={tag} label={tag} variant="outlined" />
              ))}
            </Box>
          </Grid>

          <Grid item xs={12} md={6}>
            <Typography variant="h6" gutterBottom>
              Ingredients
            </Typography>
            <List dense>
              {recipe.ingredients.map((ingredient, index) => (
                <ListItem key={index}>
                  <ListItemText primary={ingredient} />
                </ListItem>
              ))}
            </List>
          </Grid>

          <Grid item xs={12} md={6}>
            <Typography variant="h6" gutterBottom>
              Nutritional Information
            </Typography>
            <List dense>
              <ListItem>
                <ListItemText
                  primary="Calories"
                  secondary={`${recipe.nutritionalInfo.calories} kcal`}
                />
              </ListItem>
              <ListItem>
                <ListItemText
                  primary="Protein"
                  secondary={`${recipe.nutritionalInfo.protein}g`}
                />
              </ListItem>
              <ListItem>
                <ListItemText
                  primary="Carbohydrates"
                  secondary={`${recipe.nutritionalInfo.carbs}g`}
                />
              </ListItem>
              <ListItem>
                <ListItemText
                  primary="Fat"
                  secondary={`${recipe.nutritionalInfo.fat}g`}
                />
              </ListItem>
            </List>
          </Grid>

          <Grid item xs={12}>
            <Divider sx={{ my: 2 }} />
            <Typography variant="h6" gutterBottom>
              Instructions
            </Typography>
            <List>
              {recipe.instructions.map((instruction, index) => (
                <ListItem
                  key={index}
                  sx={{ display: "list-item", listStyleType: "decimal" }}
                >
                  <ListItemText primary={instruction} />
                </ListItem>
              ))}
            </List>
          </Grid>
        </Grid>
      </Paper>
    </Container>
  );
};

export default RecipeDetails;
