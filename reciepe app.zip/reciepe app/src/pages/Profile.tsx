import React, { useState } from "react";
import {
  Box,
  Typography,
  Paper,
  TextField,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Grid,
  Chip,
  SelectChangeEvent,
  Alert,
} from "@mui/material";
import { useSelector, useDispatch } from "react-redux";
import { ThunkDispatch, AnyAction } from "@reduxjs/toolkit";
import { RootState } from "../store";
import { updateProfile } from "../store/slices/authSlice";
import { User } from "../types/auth.types";

const activityLevels = [
  { value: "sedentary", label: "Sedentary" },
  { value: "light", label: "Lightly Active" },
  { value: "moderate", label: "Moderately Active" },
  { value: "very", label: "Very Active" },
  { value: "extremely", label: "Extremely Active" },
] as const;

const dietaryOptions = [
  "Vegan",
  "Vegetarian",
  "Gluten-Free",
  "Dairy-Free",
  "Keto",
  "Paleo",
  "Low-Carb",
  "Low-Fat",
];

const Profile: React.FC = () => {
  const { user } = useSelector((state: RootState) => state.auth);
  const [isEditing, setIsEditing] = useState(false);
  const dispatch =
    useDispatch<ThunkDispatch<RootState, undefined, AnyAction>>();
  const { loading, error } = useSelector((state: RootState) => state.auth);

  type FormData = {
    age: number | "";
    currentWeight: number | "";
    targetWeight: number | "";
    height: number | "";
    activityLevel: User["activityLevel"];
    dietaryPreferences: string[];
  };

  const [formData, setFormData] = useState<FormData>({
    age: user?.age || "",
    currentWeight: user?.currentWeight || "",
    targetWeight: user?.targetWeight || "",
    height: user?.height || "",
    activityLevel: user?.activityLevel || "moderate",
    dietaryPreferences: user?.dietaryPreferences || [],
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value === "" ? "" : Number(value),
    }));
  };

  const handleActivityLevelChange = (
    e: SelectChangeEvent<User["activityLevel"]>
  ) => {
    const value = e.target.value as User["activityLevel"];
    setFormData((prev) => ({
      ...prev,
      activityLevel: value,
    }));
  };

  const handleDietaryPreferenceToggle = (preference: string) => {
    setFormData((prev) => {
      const current = [...prev.dietaryPreferences];
      const index = current.indexOf(preference);
      if (index === -1) {
        current.push(preference);
      } else {
        current.splice(index, 1);
      }
      return {
        ...prev,
        dietaryPreferences: current,
      };
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const updateData: Partial<User> = {
      ...(formData.age !== "" && { age: formData.age }),
      ...(formData.currentWeight !== "" && {
        currentWeight: formData.currentWeight,
      }),
      ...(formData.targetWeight !== "" && {
        targetWeight: formData.targetWeight,
      }),
      ...(formData.height !== "" && { height: formData.height }),
      activityLevel: formData.activityLevel,
      dietaryPreferences: formData.dietaryPreferences,
    };

    try {
      const resultAction = await dispatch(updateProfile(updateData));
      if (updateProfile.fulfilled.match(resultAction)) {
        setIsEditing(false);
      }
    } catch (error) {
      console.error("Failed to update profile:", error);
    }
  };

  return (
    <Box maxWidth="md" mx="auto">
      <Paper sx={{ p: 4 }}>
        <Box
          display="flex"
          justifyContent="space-between"
          alignItems="center"
          mb={4}
        >
          <Typography variant="h4" component="h1">
            Profile
          </Typography>
          <Button variant="outlined" onClick={() => setIsEditing(!isEditing)}>
            {isEditing ? "Cancel" : "Edit Profile"}
          </Button>
        </Box>

        {error && (
          <Alert severity="error" sx={{ mb: 3 }}>
            {error}
          </Alert>
        )}
        <form onSubmit={handleSubmit}>
          <Grid container spacing={3}>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Age"
                name="age"
                type="number"
                value={formData.age}
                onChange={handleInputChange}
                disabled={!isEditing}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Height (cm)"
                name="height"
                type="number"
                value={formData.height}
                onChange={handleInputChange}
                disabled={!isEditing}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Current Weight (kg)"
                name="currentWeight"
                type="number"
                value={formData.currentWeight}
                onChange={handleInputChange}
                disabled={!isEditing}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Target Weight (kg)"
                name="targetWeight"
                type="number"
                value={formData.targetWeight}
                onChange={handleInputChange}
                disabled={!isEditing}
              />
            </Grid>
            <Grid item xs={12}>
              <FormControl fullWidth disabled={!isEditing}>
                <InputLabel>Activity Level</InputLabel>
                <Select
                  value={formData.activityLevel}
                  label="Activity Level"
                  onChange={handleActivityLevelChange}
                >
                  {activityLevels.map((level) => (
                    <MenuItem key={level.value} value={level.value}>
                      {level.label}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12}>
              <Typography variant="subtitle1" gutterBottom>
                Dietary Preferences
              </Typography>
              <Box display="flex" gap={1} flexWrap="wrap">
                {dietaryOptions.map((preference) => (
                  <Chip
                    key={preference}
                    label={preference}
                    onClick={() =>
                      isEditing && handleDietaryPreferenceToggle(preference)
                    }
                    color={
                      formData.dietaryPreferences.includes(preference)
                        ? "primary"
                        : "default"
                    }
                    clickable={isEditing}
                  />
                ))}
              </Box>
            </Grid>
            {isEditing && (
              <Grid item xs={12}>
                <Button
                  fullWidth
                  variant="contained"
                  color="primary"
                  type="submit"
                  size="large"
                  disabled={loading}
                >
                  {loading ? "Saving..." : "Save Changes"}
                </Button>
              </Grid>
            )}
          </Grid>
        </form>
      </Paper>
    </Box>
  );
};

export default Profile;
