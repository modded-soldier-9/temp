import React from "react";
import {
  Card,
  CardActions,
  CardContent,
  CardMedia,
  Button,
  Typography,
  Chip,
  Box,
  Rating,
} from "@mui/material";
import { useDispatch, useSelector } from "react-redux";
import { saveRecipe, unsaveRecipe } from "../../store/slices/recipeSlice";
import { RootState, AppDispatch } from "../../store";

interface Recipe {
  _id: string;
  name: string;
  ingredients: string[];
  instructions: string[];
  nutritionalInfo: {
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
  };
  preparationTime: number;
  difficulty: "easy" | "medium" | "hard";
  dietaryTags: string[];
  averageRating: number;
}

interface Props {
  recipe: Recipe;
  onView: (recipe: Recipe) => void;
}

const RecipeCard: React.FC<Props> = ({ recipe, onView }) => {
  const dispatch = useDispatch<AppDispatch>();
  const { user } = useSelector((state: RootState) => state.auth);
  const { savedRecipes } = useSelector((state: RootState) => state.recipe);

  const isSaved = savedRecipes.some((saved) => saved._id === recipe._id);

  const handleSave = () => {
    if (isSaved) {
      dispatch(unsaveRecipe(recipe._id));
    } else {
      dispatch(saveRecipe(recipe._id));
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "easy":
        return "success";
      case "medium":
        return "warning";
      case "hard":
        return "error";
      default:
        return "default";
    }
  };

  return (
    <Card sx={{ maxWidth: 345, height: "100%" }}>
      <CardMedia
        component="img"
        height="140"
        image="https://via.placeholder.com/300x140"
        alt={recipe.name}
      />
      <CardContent>
        <Typography gutterBottom variant="h5" component="div">
          {recipe.name}
        </Typography>
        <Box display="flex" alignItems="center" gap={1} mb={1}>
          <Rating value={recipe.averageRating} readOnly precision={0.5} />
          <Typography variant="body2" color="text.secondary">
            ({recipe.averageRating.toFixed(1)})
          </Typography>
        </Box>
        <Box display="flex" gap={1} flexWrap="wrap" mb={2}>
          <Chip
            label={`${recipe.difficulty}`}
            color={getDifficultyColor(recipe.difficulty) as any}
            size="small"
          />
          <Chip
            label={`${recipe.preparationTime} min`}
            color="primary"
            size="small"
          />
          {recipe.dietaryTags.map((tag) => (
            <Chip key={tag} label={tag} variant="outlined" size="small" />
          ))}
        </Box>
        <Typography variant="body2" color="text.secondary">
          {recipe.ingredients.slice(0, 3).join(", ")}
          {recipe.ingredients.length > 3 ? "..." : ""}
        </Typography>
      </CardContent>
      <CardActions>
        <Button size="small" onClick={() => onView(recipe)}>
          View Recipe
        </Button>
        {user && (
          <Button size="small" onClick={handleSave}>
            {isSaved ? "Unsave" : "Save"}
          </Button>
        )}
      </CardActions>
    </Card>
  );
};

export default RecipeCard;
