import React, { useState, useEffect } from "react";
import {
  Box,
  Typography,
  Button,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Chip,
  CircularProgress,
  Grid,
  Container,
  Tab,
  Tabs,
} from "@mui/material";
import { useDispatch, useSelector } from "react-redux";
import {
  searchSpoonacularRecipes,
  getRecipeRecommendations,
  getRecipesByIngredients,
  clearSearchResults,
  clearRecommendations,
  clearIngredientBasedRecipes,
} from "../../store/slices/recipeSlice";
import { RootState, AppDispatch } from "../../store";
import RecipeCard from "./RecipeCard";

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`recipe-tabpanel-${index}`}
      aria-labelledby={`recipe-tab-${index}`}
      {...other}
    >
      {value === index && <Box sx={{ p: 3 }}>{children}</Box>}
    </div>
  );
}

const RecipeGenerator: React.FC = () => {
  const dispatch = useDispatch<AppDispatch>();
  const [activeTab, setActiveTab] = useState(0);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedDiet, setSelectedDiet] = useState("");
  const [selectedIntolerances, setSelectedIntolerances] = useState<string[]>(
    []
  );
  const [ingredients, setIngredients] = useState<string[]>([]);
  const [ingredientInput, setIngredientInput] = useState("");
  const [targetCalories, setTargetCalories] = useState<number | "">(2000);

  const {
    searchResults,
    recommendations,
    ingredientBasedRecipes,
    isLoading,
    error,
  } = useSelector((state: RootState) => state.recipe);

  useEffect(() => {
    return () => {
      dispatch(clearSearchResults());
      dispatch(clearRecommendations());
      dispatch(clearIngredientBasedRecipes());
    };
  }, [dispatch]);

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setActiveTab(newValue);
  };

  const handleSearch = () => {
    if (searchQuery.trim()) {
      dispatch(
        searchSpoonacularRecipes({
          query: searchQuery,
          diet: selectedDiet,
          intolerances: selectedIntolerances.join(","),
        })
      );
    }
  };

  const handleGetRecommendations = () => {
    dispatch(
      getRecipeRecommendations({
        targetCalories: targetCalories || undefined,
        excludeIngredients: [],
      })
    );
  };

  const handleAddIngredient = () => {
    if (
      ingredientInput.trim() &&
      !ingredients.includes(ingredientInput.trim())
    ) {
      setIngredients([...ingredients, ingredientInput.trim()]);
      setIngredientInput("");
    }
  };

  const handleRemoveIngredient = (ingredient: string) => {
    setIngredients(ingredients.filter((ing) => ing !== ingredient));
  };

  const handleSearchByIngredients = () => {
    if (ingredients.length > 0) {
      dispatch(getRecipesByIngredients(ingredients));
    }
  };

  const handleViewRecipe = (recipe: any) => {
    // TODO: Navigate to recipe details
    console.log("View recipe:", recipe);
  };

  return (
    <Container maxWidth="lg">
      <Box sx={{ width: "100%", mb: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Recipe Generator
        </Typography>
        <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
          <Tabs value={activeTab} onChange={handleTabChange}>
            <Tab label="Search Recipes" />
            <Tab label="Get Recommendations" />
            <Tab label="Search by Ingredients" />
          </Tabs>
        </Box>

        <TabPanel value={activeTab} index={0}>
          <Box sx={{ mb: 3 }}>
            <TextField
              fullWidth
              label="Search recipes"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              sx={{ mb: 2 }}
            />
            <FormControl sx={{ minWidth: 200, mr: 2 }}>
              <InputLabel>Diet</InputLabel>
              <Select
                value={selectedDiet}
                label="Diet"
                onChange={(e) => setSelectedDiet(e.target.value)}
              >
                <MenuItem value="">None</MenuItem>
                <MenuItem value="vegetarian">Vegetarian</MenuItem>
                <MenuItem value="vegan">Vegan</MenuItem>
                <MenuItem value="gluten-free">Gluten Free</MenuItem>
                <MenuItem value="ketogenic">Ketogenic</MenuItem>
              </Select>
            </FormControl>
            <Button
              variant="contained"
              onClick={handleSearch}
              disabled={!searchQuery.trim() || isLoading}
            >
              {isLoading ? <CircularProgress size={24} /> : "Search"}
            </Button>
          </Box>
          <Grid container spacing={3}>
            {searchResults.map((recipe, index) => (
              <Grid item xs={12} sm={6} md={4} key={index}>
                <RecipeCard recipe={recipe as any} onView={handleViewRecipe} />
              </Grid>
            ))}
          </Grid>
        </TabPanel>

        <TabPanel value={activeTab} index={1}>
          <Box sx={{ mb: 3 }}>
            <TextField
              type="number"
              label="Target Calories"
              value={targetCalories}
              onChange={(e) =>
                setTargetCalories(e.target.value ? Number(e.target.value) : "")
              }
              sx={{ mr: 2 }}
            />
            <Button
              variant="contained"
              onClick={handleGetRecommendations}
              disabled={isLoading}
            >
              {isLoading ? (
                <CircularProgress size={24} />
              ) : (
                "Get Recommendations"
              )}
            </Button>
          </Box>
          <Grid container spacing={3}>
            {recommendations.map((recipe, index) => (
              <Grid item xs={12} sm={6} md={4} key={index}>
                <RecipeCard recipe={recipe as any} onView={handleViewRecipe} />
              </Grid>
            ))}
          </Grid>
        </TabPanel>

        <TabPanel value={activeTab} index={2}>
          <Box sx={{ mb: 3 }}>
            <TextField
              label="Add ingredient"
              value={ingredientInput}
              onChange={(e) => setIngredientInput(e.target.value)}
              onKeyPress={(e) => {
                if (e.key === "Enter") {
                  handleAddIngredient();
                }
              }}
              sx={{ mr: 2 }}
            />
            <Button
              variant="contained"
              onClick={handleAddIngredient}
              sx={{ mr: 2 }}
            >
              Add
            </Button>
            <Button
              variant="contained"
              onClick={handleSearchByIngredients}
              disabled={ingredients.length === 0 || isLoading}
            >
              {isLoading ? <CircularProgress size={24} /> : "Search Recipes"}
            </Button>
            <Box sx={{ mt: 2, mb: 2 }}>
              {ingredients.map((ingredient) => (
                <Chip
                  key={ingredient}
                  label={ingredient}
                  onDelete={() => handleRemoveIngredient(ingredient)}
                  sx={{ mr: 1, mb: 1 }}
                />
              ))}
            </Box>
          </Box>
          <Grid container spacing={3}>
            {ingredientBasedRecipes.map((recipe, index) => (
              <Grid item xs={12} sm={6} md={4} key={index}>
                <RecipeCard recipe={recipe as any} onView={handleViewRecipe} />
              </Grid>
            ))}
          </Grid>
        </TabPanel>

        {error && (
          <Typography color="error" sx={{ mt: 2 }}>
            {error}
          </Typography>
        )}
      </Box>
    </Container>
  );
};

export default RecipeGenerator;
